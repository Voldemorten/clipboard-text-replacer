console.log('This is a popup!');
chrome.runtime.openOptionsPage();
